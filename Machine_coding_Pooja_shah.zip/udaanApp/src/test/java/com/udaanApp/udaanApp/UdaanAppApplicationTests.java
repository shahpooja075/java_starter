package com.udaanApp.udaanApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UdaanAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
